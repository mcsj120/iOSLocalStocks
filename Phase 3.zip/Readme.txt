ReadMe.txt
- Final UML.pdf - UML diagram of class
	Note: some parts of the uml are missing because LucidChart doesn't allow over 60 items. All view controllers are connected to the ViewController class as inheritance, which is an open arrow. Composition relationships are modeled by a filled in arrow. Classes utilizing the StockModel.swift and UserModel.swift classes are involved in composition.

- Final MVC.pdf - MVC architecture of final project
- LocalStocks.pptx - Powerpoint slides I used for my presentation
- Link.txt - Link to youtube containing presentation