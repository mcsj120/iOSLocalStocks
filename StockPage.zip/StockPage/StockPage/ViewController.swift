//
//  ViewController.swift
//  StockPage
//
//  Created by Michael StOnge on 10/14/18.
//  Copyright © 2018 Michael StOnge. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tickerSymbol: UITextField!
    @IBOutlet weak var Info: UITextField!
    var test2: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func getValue()
    {
        forData
            { result in
                if(result[0] == "error")
                {
                    self.test2 = "error"
                }
                var stuff = [String]()
                for item in result
                {
                    stuff.append(item)
                    let parse = item.components(separatedBy: "=")
                    if parse[0] == "2018-10-04"
                    {
                        self.test2 = parse[1]
                    }
                    
                }
        }
        if(test2 != nil && test2 != "error")
        {
            let arr = test2!.components(separatedBy: ".")
            let subs = arr[1].prefix(2)
            self.Info.text = "$\(arr[0]).\(subs)"
        }
        else
        {
            self.Info.text = "Error"
            
        }
        
    }
    
    @IBAction func calc(_ sender: Any) {
        getValue()
        
    }
    
    func forData(completion: @escaping ([String]) -> ())
    {
        var result = [String]()
        let api = "HA1B7557DRPRIY78"
        var stock: String = "MSFT"
        if(self.tickerSymbol.text?.isEmpty == false)
        {
            if(false == self.tickerSymbol.text?.contains(" "))
            {
                stock = self.tickerSymbol.text!.uppercased()
            }

        }
        let s = "https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=\(stock)&interval=5min&apikey=\(api)"
        
        let url = URL(string: s)
        let task = URLSession.shared.dataTask(with: url!) { (data: Data?, response: URLResponse?, error: Error?) in
            if error != nil {
                result[0] = "error"
            }
            else{
                if let content = data{
                    do {
                        let myJson = try JSONSerialization.jsonObject(with: content, options: JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                        if let time = myJson["Time Series (Daily)"] as? NSDictionary
                        {
                            for (key, value) in time
                            {
                                if let value = value as? Dictionary<String, String>
                                {
                                    //var iterator = 0
                                    if let close = value["4. close"]
                                    {
                                        result.append("\(key)=\(close)")
                                        //print("\(key) CloseStock-> \(close)")
                                    }
                                }
                            }
                        }
                    }
                    catch {
                        result[0] = "error"
                        completion(result)
                        print(error.localizedDescription)
                    }
                }
                if(result.isEmpty == false)
                {
                    completion(result)
                }
            }
            }
            task.resume()
        
    }
    


}

